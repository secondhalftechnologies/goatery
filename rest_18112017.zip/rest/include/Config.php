<?php 


/** Database config */
//define('DB_USERNAME', 'root');  
//define('DB_PASSWORD', '');  
define('DB_USERNAME', 'sqyard_2017');  
define('DB_PASSWORD', 'Sqyard@!2017');  
define('DB_HOST', 'localhost');  
define('DB_NAME', 'sqyard_2017');


/** Debug modes */
define('PHP_DEBUG_MODE', true);  
define('SLIM_DEBUG', true);


